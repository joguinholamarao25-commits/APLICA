import { GoogleGenAI } from "@google/genai";
import { ServiceStatus } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Define a estrutura de resposta esperada para múltiplos agendamentos
interface ParsedAppointment {
  clientName: string;
  serviceDate: string; // ISO Date string YYYY-MM-DD
  startTime: string; // HH:mm
  services: string;
  totalPrice: number;
  confidence: number;
}

export const parseVoiceCommand = async (transcript: string): Promise<ParsedAppointment[]> => {
  const today = new Date();
  const dayName = today.toLocaleDateString('pt-BR', { weekday: 'long' });
  const fullDate = today.toLocaleDateString('pt-BR');

  const prompt = `
    Hoje é ${dayName}, dia ${fullDate}.
    
    Analise o seguinte comando de voz de um prestador de serviços de limpeza de estofados e extraia os agendamentos solicitados.
    O comando pode conter um ou múltiplos agendamentos.
    
    Comando: "${transcript}"
    
    Regras:
    1. Identifique o nome do cliente. Se não for claro, use "Cliente (Voz)".
    2. Identifique a data relativa (amanhã, depois de amanhã, próxima segunda) e converta para formato YYYY-MM-DD.
    3. Identifique o horário. Se não especificado, sugira "08:00".
    4. Identifique o serviço e o valor. Se o valor não for dito, coloque 0.
    5. Retorne um JSON estrito.
    
    Schema esperado:
    {
      "appointments": [
        {
          "clientName": "string",
          "serviceDate": "YYYY-MM-DD",
          "startTime": "HH:mm",
          "services": "string",
          "totalPrice": number
        }
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const jsonText = response.text || "{}";
    const parsed = JSON.parse(jsonText);
    
    return parsed.appointments || [];
  } catch (error) {
    console.error("Erro ao processar comando de voz:", error);
    return [];
  }
};