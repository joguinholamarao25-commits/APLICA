import { GoogleGenAI } from "@google/genai";
import { QuoteItem } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSalesMessage = async (
  clientName: string,
  items: QuoteItem[],
  totalPrice: number
): Promise<string> => {
  try {
    const itemsDescription = items.map(item => 
      `- ${item.category} (${item.description}): Estado: ${item.condition}`
    ).join('\n');

    const prompt = `
      Atue como um especialista em vendas de higienização e impermeabilização de estofados.
      Crie uma mensagem curta, persuasiva e profissional para enviar no WhatsApp para o cliente ${clientName}.
      
      Detalhes do serviço solicitado:
      ${itemsDescription}
      
      Valor Total: R$ ${totalPrice.toFixed(2)}
      
      Estrutura da mensagem:
      1. Saudação cordial.
      2. Resumo técnico breve dos benefícios da higienização para os itens citados (focar em saúde, remoção de ácaros/manchas e estética).
      3. Apresentação do valor.
      4. Chamada para ação (agendar data).
      
      Use emojis adequados (limpeza, brilho, sofá). A linguagem deve ser brasileira, confiável e educada. Não use markdown na resposta final, apenas o texto puro pronto para copiar.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Olá! Segue seu orçamento de higienização. Por favor, entre em contato para mais detalhes.";
  } catch (error) {
    console.error("Erro ao gerar mensagem com Gemini:", error);
    return `Olá ${clientName}, segue o orçamento para a higienização dos seus estofados. Valor Total: R$ ${totalPrice.toFixed(2)}. Podemos agendar?`;
  }
};