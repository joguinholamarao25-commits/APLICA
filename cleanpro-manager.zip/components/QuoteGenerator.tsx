import React, { useState } from 'react';
import { QuoteItem, ServiceCategory } from '../types';
import { generateSalesMessage } from '../services/geminiService';
import { Plus, Trash2, Wand2, Send, Loader2, Zap } from 'lucide-react';

// Catálogo predefinido para agilizar o preenchimento
const PREDEFINED_SERVICES = [
  { label: 'Sofá Retrátil 2 Lugares', category: ServiceCategory.SOFA, price: 220.00, desc: 'Lavagem ecológica profunda' },
  { label: 'Sofá Retrátil 3 Lugares', category: ServiceCategory.SOFA, price: 280.00, desc: 'Lavagem ecológica profunda' },
  { label: 'Sofá de Canto (L)', category: ServiceCategory.SOFA, price: 350.00, desc: 'Higienização completa' },
  { label: 'Cadeira de Jantar (unid)', category: ServiceCategory.CHAIR, price: 35.00, desc: 'Assento e encosto' },
  { label: 'Poltrona', category: ServiceCategory.CHAIR, price: 120.00, desc: 'Higienização tecido' },
  { label: 'Colchão Casal', category: ServiceCategory.MATTRESS, price: 200.00, desc: 'Remoção de ácaros e manchas' },
  { label: 'Colchão Queen/King', category: ServiceCategory.MATTRESS, price: 250.00, desc: 'Higienização premium' },
  { label: 'Impermeabilização (Padrão)', category: ServiceCategory.OTHER, price: 180.00, desc: 'Blindagem contra líquidos' },
  { label: 'Bancos Carro (Completo)', category: ServiceCategory.CAR_INTERIOR, price: 250.00, desc: 'Bancos, teto e carpetes' },
];

export const QuoteGenerator: React.FC = () => {
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  
  const [items, setItems] = useState<QuoteItem[]>([]);
  
  // Temporary state for adding a new item
  const [newItemCategory, setNewItemCategory] = useState<ServiceCategory>(ServiceCategory.SOFA);
  const [newItemDescription, setNewItemDescription] = useState('');
  const [newItemCondition, setNewItemCondition] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');

  const [generatedMessage, setGeneratedMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Função para preencher dados rapidamente baseado no catálogo
  const handleQuickSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedLabel = e.target.value;
    const service = PREDEFINED_SERVICES.find(s => s.label === selectedLabel);
    
    if (service) {
      setNewItemCategory(service.category);
      setNewItemDescription(service.label); // Coloca o nome no campo de descrição para facilitar
      setNewItemPrice(service.price.toString());
      setNewItemCondition('Uso normal'); // Valor default
    }
  };

  const handleAddItem = () => {
    if (!newItemDescription || !newItemPrice) return;
    
    const item: QuoteItem = {
      category: newItemCategory,
      description: newItemDescription,
      condition: newItemCondition,
      price: parseFloat(newItemPrice)
    };
    
    setItems([...items, item]);
    // Reset inputs
    setNewItemDescription('');
    setNewItemCondition('');
    setNewItemPrice('');
  };

  const handleRemoveItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const totalPrice = items.reduce((sum, item) => sum + item.price, 0);

  const handleGenerateAI = async () => {
    if (items.length === 0 || !clientName) {
      alert("Adicione itens e o nome do cliente.");
      return;
    }
    setIsLoading(true);
    const message = await generateSalesMessage(clientName, items, totalPrice);
    setGeneratedMessage(message);
    setIsLoading(false);
  };

  const handleSendWhatsApp = () => {
    if (!clientPhone || !generatedMessage) {
        alert("Preencha o telefone e gere a mensagem primeiro.");
        return;
    }
    // Remove formatting characters from phone for the link
    const cleanPhone = clientPhone.replace(/\D/g, '');
    const encodedMessage = encodeURIComponent(generatedMessage);
    window.open(`https://wa.me/55${cleanPhone}?text=${encodedMessage}`, '_blank');
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <header>
        <h2 className="text-2xl font-bold text-gray-800">Novo Orçamento</h2>
        <p className="text-gray-500">Crie orçamentos detalhados e use IA para gerar a mensagem de venda.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Input Form */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
                1. Dados do Cliente
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Cliente</label>
                <input 
                  type="text" 
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  className="w-full p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ex: Maria Silva"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">WhatsApp (com DDD)</label>
                <input 
                  type="tel" 
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  className="w-full p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                  placeholder="Ex: 11999999999"
                />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-800">2. Itens do Serviço</h3>
                <div className="flex items-center gap-1 text-xs bg-amber-50 text-amber-700 px-2 py-1 rounded-md border border-amber-100">
                    <Zap size={12} /> Seleção Rápida
                </div>
            </div>

            {/* Quick Select Dropdown */}
            <div className="mb-4">
                <label className="block text-xs font-medium text-gray-500 uppercase mb-1">Preencher com item do catálogo:</label>
                <select 
                    onChange={handleQuickSelect}
                    className="w-full p-2 border border-gray-300 bg-gray-50 rounded-lg outline-none text-sm text-gray-700 focus:border-blue-500"
                    defaultValue=""
                >
                    <option value="" disabled>-- Selecione um serviço comum --</option>
                    {PREDEFINED_SERVICES.map((s, i) => (
                        <option key={i} value={s.label}>{s.label} - R$ {s.price}</option>
                    ))}
                </select>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3 pt-4 border-t border-gray-100">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-500 uppercase mb-1">Categoria</label>
                <select 
                  value={newItemCategory}
                  onChange={(e) => setNewItemCategory(e.target.value as ServiceCategory)}
                  className="w-full p-2 border border-gray-200 rounded-lg outline-none bg-white"
                >
                  {Object.values(ServiceCategory).map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              
              <div className="sm:col-span-2">
                 <label className="block text-xs font-medium text-gray-500 uppercase mb-1">Descrição (Tamanho/Modelo)</label>
                 <input 
                    type="text"
                    value={newItemDescription}
                    onChange={(e) => setNewItemDescription(e.target.value)}
                    placeholder="Ex: 3 Lugares Retrátil"
                    className="w-full p-2 border border-gray-200 rounded-lg outline-none"
                 />
              </div>

              <div className="sm:col-span-2">
                 <label className="block text-xs font-medium text-gray-500 uppercase mb-1">Estado/Obs</label>
                 <input 
                    type="text"
                    value={newItemCondition}
                    onChange={(e) => setNewItemCondition(e.target.value)}
                    placeholder="Ex: Manchas leves"
                    className="w-full p-2 border border-gray-200 rounded-lg outline-none"
                 />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-500 uppercase mb-1">Preço (R$)</label>
                <div className="flex gap-2">
                  <input 
                      type="number"
                      value={newItemPrice}
                      onChange={(e) => setNewItemPrice(e.target.value)}
                      placeholder="0.00"
                      className="w-full p-2 border border-gray-200 rounded-lg outline-none"
                  />
                  <button 
                    onClick={handleAddItem}
                    className="bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center min-w-[3rem]"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              </div>
            </div>

            {/* List of items */}
            <div className="mt-4 space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center bg-gray-50 p-3 rounded-lg text-sm border border-gray-100">
                  <div>
                    <span className="font-semibold text-gray-700">{item.category}</span>
                    <p className="text-gray-500 text-xs">{item.description}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-gray-800">R$ {item.price.toFixed(2)}</span>
                    <button onClick={() => handleRemoveItem(idx)} className="text-red-400 hover:text-red-600">
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
              {items.length > 0 && (
                <div className="flex justify-between items-center pt-3 border-t border-gray-100">
                    <span className="font-bold text-gray-700">Total</span>
                    <span className="font-bold text-xl text-blue-600">R$ {totalPrice.toFixed(2)}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: AI Generation */}
        <div className="flex flex-col h-full bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Wand2 size={18} className="text-purple-500"/> 
            Gerador de Mensagem com IA
          </h3>
          
          <div className="flex-grow flex flex-col gap-4">
             <div className="relative flex-grow">
               <textarea
                 value={generatedMessage}
                 onChange={(e) => setGeneratedMessage(e.target.value)}
                 placeholder="A mensagem gerada pela IA aparecerá aqui..."
                 className="w-full h-full min-h-[300px] p-4 bg-gray-50 border border-gray-200 rounded-xl resize-none outline-none focus:ring-2 focus:ring-purple-200 transition-all text-sm leading-relaxed"
               />
               {!generatedMessage && !isLoading && (
                 <div className="absolute inset-0 flex items-center justify-center text-gray-400 pointer-events-none p-8 text-center">
                    <p>Adicione itens ao orçamento e clique em "Gerar" para criar uma mensagem personalizada para o WhatsApp.</p>
                 </div>
               )}
               {isLoading && (
                 <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80 rounded-xl z-10 backdrop-blur-sm">
                    <Loader2 className="animate-spin text-purple-600 mb-2" size={32} />
                    <span className="text-sm font-medium text-purple-600">A IA está escrevendo...</span>
                 </div>
               )}
             </div>

             <div className="flex flex-col sm:flex-row gap-3">
               <button
                 onClick={handleGenerateAI}
                 disabled={isLoading || items.length === 0}
                 className={`
                    flex-1 py-3 px-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors
                    ${items.length === 0 
                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                        : 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg shadow-purple-200'}
                 `}
               >
                 <Wand2 size={18} />
                 {isLoading ? 'Gerando...' : 'Gerar Texto'}
               </button>

               <button
                 onClick={handleSendWhatsApp}
                 disabled={!generatedMessage}
                 className={`
                    flex-1 py-3 px-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors
                    ${!generatedMessage 
                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed' 
                        : 'bg-green-500 text-white hover:bg-green-600 shadow-lg shadow-green-200'}
                 `}
               >
                 <Send size={18} />
                 Enviar WhatsApp
               </button>
             </div>
          </div>
        </div>

      </div>
    </div>
  );
};