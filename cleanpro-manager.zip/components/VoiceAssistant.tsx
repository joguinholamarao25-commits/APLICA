import React, { useState, useEffect } from 'react';
import { Mic, MicOff, Loader2, Check, X, CalendarCheck } from 'lucide-react';
import { parseVoiceCommand } from '../services/voiceAgentService';
import { Appointment, ServiceStatus } from '../types';

interface VoiceAssistantProps {
  onAddAppointments: (appointments: Appointment[]) => void;
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onAddAppointments }) => {
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [recognition, setRecognition] = useState<any>(null);
  const [pendingAppointments, setPendingAppointments] = useState<any[]>([]);
  const [showConfirmation, setShowConfirmation] = useState(false);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.lang = 'pt-BR';
      recognitionInstance.interimResults = false;

      recognitionInstance.onstart = () => setIsListening(true);
      
      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      recognitionInstance.onresult = async (event: any) => {
        const text = event.results[0][0].transcript;
        setTranscript(text);
        handleProcessAudio(text);
      };

      recognitionInstance.onerror = (event: any) => {
        console.error("Erro no reconhecimento de voz", event.error);
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    } else {
      console.warn("Navegador não suporta reconhecimento de voz.");
    }
  }, []);

  const toggleListening = () => {
    if (!recognition) {
        alert("Seu navegador não suporta comandos de voz.");
        return;
    }

    if (isListening) {
      recognition.stop();
    } else {
      setTranscript('');
      setPendingAppointments([]);
      setShowConfirmation(false);
      recognition.start();
    }
  };

  const handleProcessAudio = async (text: string) => {
    setIsProcessing(true);
    try {
      const extractedData = await parseVoiceCommand(text);
      if (extractedData && extractedData.length > 0) {
        setPendingAppointments(extractedData);
        setShowConfirmation(true);
      } else {
        alert("Não entendi o comando de agendamento. Tente novamente.");
      }
    } catch (error) {
      console.error(error);
      alert("Erro ao processar com IA.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleConfirm = () => {
    const newAppointments: Appointment[] = pendingAppointments.map(item => ({
      id: Date.now().toString() + Math.random().toString(),
      clientName: item.clientName,
      clientPhone: '', // Opcional: A IA poderia tentar extrair se falado digito a digito, mas complexo
      clientAddress: 'Endereço a definir',
      serviceDate: new Date(item.serviceDate + 'T' + item.startTime),
      startTime: item.startTime,
      durationHours: 2, // Padrão
      services: item.services,
      totalPrice: item.totalPrice,
      status: ServiceStatus.PENDING,
      isPaid: false
    }));

    onAddAppointments(newAppointments);
    setShowConfirmation(false);
    setPendingAppointments([]);
    setTranscript('');
  };

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4">
        
        {/* Transcript Bubble (While listening/processing) */}
        {(isListening || isProcessing) && (
             <div className="bg-black/80 text-white p-4 rounded-2xl max-w-xs mb-2 backdrop-blur-md shadow-lg animate-in fade-in slide-in-from-bottom-4">
                {isListening ? (
                    <div className="flex items-center gap-2">
                        <span className="animate-pulse w-2 h-2 bg-red-500 rounded-full"></span>
                        <p className="text-sm">Ouvindo...</p>
                    </div>
                ) : (
                    <div className="flex items-center gap-2 text-purple-300">
                        <Loader2 className="animate-spin h-4 w-4" />
                        <p className="text-sm">A IA está processando...</p>
                    </div>
                )}
                {transcript && <p className="mt-2 text-sm italic opacity-90">"{transcript}"</p>}
             </div>
        )}

        <button
          onClick={toggleListening}
          className={`
            p-4 rounded-full shadow-xl transition-all duration-300 flex items-center justify-center
            ${isListening 
                ? 'bg-red-500 hover:bg-red-600 scale-110 ring-4 ring-red-200' 
                : 'bg-indigo-600 hover:bg-indigo-700 text-white'}
          `}
          title="Assistente de Voz"
        >
          {isListening ? <MicOff size={24} className="text-white" /> : <Mic size={24} />}
        </button>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in fade-in duration-200">
            <div className="bg-indigo-600 p-4 text-white flex justify-between items-center">
                <h3 className="font-bold flex items-center gap-2">
                    <CalendarCheck size={20} />
                    Confirmar Agendamentos
                </h3>
                <button onClick={() => setShowConfirmation(false)} className="hover:bg-indigo-700 p-1 rounded">
                    <X size={20} />
                </button>
            </div>
            
            <div className="p-6">
                <p className="text-sm text-gray-500 mb-4">A IA entendeu o seguinte comando:</p>
                <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-700 italic mb-6 border border-gray-100">
                    "{transcript}"
                </div>

                <div className="space-y-3 max-h-60 overflow-y-auto">
                    {pendingAppointments.map((appt, idx) => (
                        <div key={idx} className="flex gap-3 bg-indigo-50 p-3 rounded-xl border border-indigo-100">
                            <div className="bg-white p-2 rounded-lg text-center min-w-[3rem] h-fit border border-indigo-50 shadow-sm">
                                <span className="block text-xs text-indigo-600 font-bold uppercase">
                                    {new Date(appt.serviceDate).toLocaleDateString('pt-BR', {weekday: 'short'}).slice(0,3)}
                                </span>
                                <span className="block text-lg font-bold text-gray-800">
                                    {appt.startTime}
                                </span>
                            </div>
                            <div>
                                <h4 className="font-bold text-gray-800">{appt.clientName}</h4>
                                <p className="text-sm text-gray-600">{appt.services}</p>
                                <p className="text-sm font-semibold text-green-600">R$ {appt.totalPrice.toFixed(2)}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="p-4 bg-gray-50 border-t border-gray-100 flex gap-3">
                <button 
                    onClick={() => setShowConfirmation(false)}
                    className="flex-1 py-3 bg-white border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-100"
                >
                    Cancelar
                </button>
                <button 
                    onClick={handleConfirm}
                    className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
                >
                    <Check size={18} /> Confirmar
                </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};