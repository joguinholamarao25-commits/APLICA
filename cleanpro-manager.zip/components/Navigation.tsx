import React from 'react';
import { LayoutDashboard, Calendar, FileText, Menu, X, SprayCan } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  isMobileMenuOpen: boolean;
  setIsMobileMenuOpen: (isOpen: boolean) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ 
  currentView, 
  setCurrentView,
  isMobileMenuOpen,
  setIsMobileMenuOpen
}) => {
  
  const navItems = [
    { id: 'dashboard', label: 'Painel', icon: <LayoutDashboard size={20} /> },
    { id: 'calendar', label: 'Agenda', icon: <Calendar size={20} /> },
    { id: 'quotes', label: 'Orçamentos', icon: <FileText size={20} /> },
  ];

  const handleNavClick = (viewId: string) => {
    setCurrentView(viewId);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden bg-blue-600 text-white p-4 flex justify-between items-center fixed top-0 left-0 right-0 z-50 shadow-md">
        <div className="flex items-center gap-2">
            <SprayCan className="h-6 w-6" />
            <h1 className="font-bold text-lg">CleanPro</h1>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Sidebar (Desktop) & Drawer (Mobile) */}
      <div className={`
        fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out
        md:translate-x-0 md:static md:h-screen md:shadow-none border-r border-gray-200
        ${isMobileMenuOpen ? 'translate-x-0 pt-16' : '-translate-x-full md:pt-0'}
      `}>
        <div className="p-6 hidden md:flex items-center gap-2 border-b border-gray-100">
           <div className="bg-blue-100 p-2 rounded-lg text-blue-600">
             <SprayCan className="h-6 w-6" />
           </div>
           <div>
              <h1 className="font-bold text-xl text-gray-800">CleanPro</h1>
              <p className="text-xs text-gray-500">Gestão de Limpeza</p>
           </div>
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors font-medium
                ${currentView === item.id 
                  ? 'bg-blue-50 text-blue-600' 
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'}
              `}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-gray-100 bg-gray-50">
           <div className="text-xs text-gray-500 text-center">
             Versão 1.0.0
           </div>
        </div>
      </div>

      {/* Overlay for mobile */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  );
};