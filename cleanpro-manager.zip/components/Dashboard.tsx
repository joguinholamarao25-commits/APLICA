import React, { useState } from 'react';
import { Appointment, ServiceStatus, Expense } from '../types';
import { TrendingUp, Users, CalendarCheck, DollarSign, Wallet, AlertCircle, Copy, Check, TrendingDown, Plus, Trash2, Bell, MessageCircle, Send } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DashboardProps {
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  expenses: Expense[];
  setExpenses: React.Dispatch<React.SetStateAction<Expense[]>>;
}

export const Dashboard: React.FC<DashboardProps> = ({ appointments, setAppointments, expenses, setExpenses }) => {
  const [copied, setCopied] = useState(false);
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  
  // Expense Form State
  const [expDesc, setExpDesc] = useState('');
  const [expAmount, setExpAmount] = useState('');
  const [expCat, setExpCat] = useState('Combustível');

  // Financial Stats
  const totalRevenue = appointments.reduce((acc, curr) => acc + curr.totalPrice, 0);
  const receivedRevenue = appointments.filter(a => a.isPaid).reduce((acc, curr) => acc + curr.totalPrice, 0);
  const totalExpenses = expenses.reduce((acc, curr) => acc + curr.amount, 0);
  const pendingRevenue = totalRevenue - receivedRevenue;
  const netProfit = receivedRevenue - totalExpenses;

  // Lógica de Lembretes (Clientes de Amanhã)
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowString = tomorrow.toDateString();

  const reminderList = appointments.filter(a => 
    new Date(a.serviceDate).toDateString() === tomorrowString && 
    a.status !== ServiceStatus.CANCELLED &&
    a.status !== ServiceStatus.COMPLETED &&
    !a.reminderSent
  );

  const handleSendReminder = (appt: Appointment) => {
    if (!appt.clientPhone) return;
    
    const firstName = appt.clientName.split(' ')[0];
    const message = `Olá ${firstName}! 👋 Passando para confirmar nosso agendamento de higienização para amanhã às ${appt.startTime}. Endereço: ${appt.clientAddress}. Tudo certo para receber a gente?`;
    
    const cleanPhone = appt.clientPhone.replace(/\D/g, '');
    const url = `https://wa.me/55${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    window.open(url, '_blank');

    // Marcar como enviado
    setAppointments(appointments.map(a => 
      a.id === appt.id ? { ...a, reminderSent: true } : a
    ));
  };

  const handleCopyRoute = () => {
    const today = new Date().toDateString();
    const todaysJobs = appointments.filter(a => new Date(a.serviceDate).toDateString() === today);
    
    if (todaysJobs.length === 0) {
        alert("Sem agendamentos para hoje.");
        return;
    }

    const text = `📅 *Roteiro de Hoje - CleanPro*\n\n` + todaysJobs
        .sort((a, b) => a.startTime.localeCompare(b.startTime))
        .map(job => `⏰ ${job.startTime} - ${job.clientName}\n📍 ${job.clientAddress}\n💰 R$ ${job.totalPrice}\n------------------`)
        .join('\n');
    
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddExpense = (e: React.FormEvent) => {
      e.preventDefault();
      if (!expDesc || !expAmount) return;

      const newExpense: Expense = {
          id: Date.now().toString(),
          description: expDesc,
          amount: parseFloat(expAmount),
          category: expCat as any,
          date: new Date()
      };

      setExpenses([newExpense, ...expenses]);
      setExpDesc('');
      setExpAmount('');
      setIsExpenseModalOpen(false);
  };

  const handleDeleteExpense = (id: string) => {
      setExpenses(expenses.filter(e => e.id !== id));
  };

  const StatsCard = ({ title, value, icon: Icon, color, subValue, textColor }: { title: string, value: string, icon: any, color: string, subValue?: string, textColor?: string }) => (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4">
      <div className={`p-3 rounded-xl ${color} bg-opacity-10 text-${color.split('-')[1]}-600`}>
        <Icon size={24} className={color.replace('bg-', 'text-')} />
      </div>
      <div>
        <p className="text-sm text-gray-500 font-medium">{title}</p>
        <h3 className={`text-2xl font-bold ${textColor || 'text-gray-800'}`}>{value}</h3>
        {subValue && <p className="text-xs text-gray-400 mt-1">{subValue}</p>}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in pb-20">
      <header className="mb-8 flex flex-col md:flex-row md:justify-between md:items-end gap-4">
        <div>
            <h2 className="text-2xl font-bold text-gray-800">Painel Geral</h2>
            <p className="text-gray-500">Visão geral do seu negócio e finanças</p>
        </div>
        <button 
            onClick={handleCopyRoute}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 transition-colors text-sm font-medium shadow-sm"
        >
            {copied ? <Check size={16} className="text-green-500" /> : <Copy size={16} />}
            {copied ? "Copiado!" : "Copiar Roteiro de Hoje"}
        </button>
      </header>

      {/* Reminder Alert Section */}
      {reminderList.length > 0 && (
        <div className="bg-orange-50 border border-orange-100 rounded-2xl p-4 md:p-6 mb-6 animate-in slide-in-from-top-2">
            <div className="flex items-start gap-3">
                <div className="p-2 bg-orange-100 rounded-lg text-orange-600">
                    <Bell size={24} />
                </div>
                <div className="flex-1">
                    <h3 className="font-bold text-gray-800 text-lg">Lembretes para Amanhã ({reminderList.length})</h3>
                    <p className="text-sm text-gray-600 mb-4">Envie uma mensagem de confirmação para evitar clientes ausentes.</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {reminderList.map(appt => (
                            <div key={appt.id} className="bg-white p-3 rounded-xl border border-orange-100 shadow-sm flex justify-between items-center">
                                <div>
                                    <p className="font-bold text-gray-800 text-sm">{appt.clientName}</p>
                                    <p className="text-xs text-gray-500">{appt.startTime} • {appt.services.split(' ')[0]}...</p>
                                </div>
                                <button 
                                    onClick={() => handleSendReminder(appt)}
                                    className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-lg transition-colors flex items-center gap-2 text-xs font-bold shadow-md shadow-green-100"
                                >
                                    <Send size={12} /> Avisar
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
      )}

      {/* Financial Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Recebido (Bruto)" 
          value={`R$ ${receivedRevenue.toLocaleString('pt-BR')}`} 
          icon={Wallet} 
          color="bg-blue-500"
          subValue="Entrada em caixa"
        />
        <StatsCard 
          title="Despesas" 
          value={`R$ ${totalExpenses.toLocaleString('pt-BR')}`} 
          icon={TrendingDown} 
          color="bg-red-500" 
          subValue="Gasolina, produtos..."
        />
        <StatsCard 
          title="Lucro Líquido" 
          value={`R$ ${netProfit.toLocaleString('pt-BR')}`} 
          icon={TrendingUp} 
          color="bg-green-500"
          textColor="text-green-600" 
          subValue="O que sobrou no bolso"
        />
        <StatsCard 
          title="A Receber" 
          value={`R$ ${pendingRevenue.toLocaleString('pt-BR')}`} 
          icon={AlertCircle} 
          color="bg-orange-500" 
          subValue="Serviços realizados/agendados"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
        
        {/* Expenses Module */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 lg:col-span-1 flex flex-col">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-800">Despesas Recentes</h3>
                <button 
                    onClick={() => setIsExpenseModalOpen(true)}
                    className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors"
                >
                    <Plus size={20} />
                </button>
            </div>
            
            <div className="flex-1 overflow-y-auto max-h-64 space-y-3 pr-2">
                {expenses.length === 0 ? (
                    <p className="text-sm text-gray-400 text-center py-4">Nenhuma despesa registrada.</p>
                ) : (
                    expenses.map(exp => (
                        <div key={exp.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl border border-gray-100">
                            <div>
                                <p className="font-medium text-gray-800 text-sm">{exp.description}</p>
                                <p className="text-xs text-gray-500">{exp.category} • {new Date(exp.date).toLocaleDateString()}</p>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="font-bold text-red-600 text-sm">- R$ {exp.amount.toFixed(2)}</span>
                                <button onClick={() => handleDeleteExpense(exp.id)} className="text-gray-400 hover:text-red-500">
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* Upcoming Jobs */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 lg:col-span-2">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Próximos Serviços</h3>
          <div className="space-y-4">
            {appointments
             .filter(a => a.status !== ServiceStatus.CANCELLED)
             .sort((a,b) => new Date(a.serviceDate).getTime() - new Date(b.serviceDate).getTime())
             .slice(0, 4)
             .map((appt) => (
              <div key={appt.id} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors border border-transparent hover:border-gray-100 relative">
                <div className={`
                    bg-blue-50 text-blue-600 font-bold rounded-lg p-2 text-center min-w-[3.5rem]
                    ${appt.status === ServiceStatus.COMPLETED ? 'bg-green-50 text-green-600' : ''}
                `}>
                  <span className="block text-xs uppercase">{new Date(appt.serviceDate).toLocaleString('pt-BR', { month: 'short' })}</span>
                  <span className="block text-lg">{new Date(appt.serviceDate).getDate()}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-800 text-sm truncate">{appt.clientName}</h4>
                  <p className="text-xs text-gray-500 truncate">{appt.services}</p>
                  <div className="flex items-center gap-2 mt-1">
                      <span className="inline-block px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] rounded-full font-medium">
                        {appt.startTime}
                      </span>
                      {appt.isPaid && (
                          <span className="text-[10px] text-green-600 font-bold flex items-center">
                              <DollarSign size={10} /> Pago
                          </span>
                      )}
                      {appt.reminderSent && new Date(appt.serviceDate) > new Date() && (
                          <span className="text-[10px] text-orange-600 font-bold flex items-center">
                              <Check size={10} /> Lembrete Enviado
                          </span>
                      )}
                  </div>
                </div>
              </div>
            ))}
            {appointments.length === 0 && (
              <p className="text-sm text-gray-400 text-center py-8">Sem agendamentos futuros.</p>
            )}
          </div>
        </div>
      </div>

      {/* Add Expense Modal */}
      {isExpenseModalOpen && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">Nova Despesa</h3>
                  <form onSubmit={handleAddExpense} className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                          <input 
                            autoFocus
                            type="text" 
                            className="w-full p-2 border rounded-lg" 
                            placeholder="Ex: Gasolina, Almoço"
                            value={expDesc}
                            onChange={e => setExpDesc(e.target.value)}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Valor (R$)</label>
                          <input 
                            type="number" 
                            step="0.01"
                            className="w-full p-2 border rounded-lg" 
                            placeholder="0.00"
                            value={expAmount}
                            onChange={e => setExpAmount(e.target.value)}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Categoria</label>
                          <select 
                            className="w-full p-2 border rounded-lg"
                            value={expCat}
                            onChange={e => setExpCat(e.target.value)}
                          >
                              <option>Combustível</option>
                              <option>Alimentação</option>
                              <option>Produtos</option>
                              <option>Manutenção</option>
                              <option>Outros</option>
                          </select>
                      </div>
                      <div className="flex gap-2 pt-2">
                          <button 
                            type="button" 
                            onClick={() => setIsExpenseModalOpen(false)}
                            className="flex-1 py-2 text-gray-600 bg-gray-100 rounded-lg font-medium"
                          >
                              Cancelar
                          </button>
                          <button 
                            type="submit" 
                            className="flex-1 py-2 text-white bg-red-500 rounded-lg font-medium hover:bg-red-600"
                          >
                              Adicionar
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};