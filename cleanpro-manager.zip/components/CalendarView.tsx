import React, { useState } from 'react';
import { Appointment, ServiceStatus } from '../types';
import { Clock, MapPin, CheckCircle, XCircle, User, Plus, MessageCircle, Navigation, ExternalLink, DollarSign, Star, CalendarPlus, ShieldAlert, ListChecks, Play } from 'lucide-react';

interface CalendarViewProps {
  appointments: Appointment[];
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ appointments, setAppointments }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [activeChecklistId, setActiveChecklistId] = useState<string | null>(null);
  
  // Checklist State
  const [checklistSteps, setChecklistSteps] = useState({
      photoBefore: false,
      protectFloor: false,
      vacuum: false,
      applyProduct: false,
      extract: false,
      photoAfter: false,
      cleanArea: false
  });

  // New Appointment State
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [serviceDate, setServiceDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [services, setServices] = useState('');
  const [totalPrice, setTotalPrice] = useState('');
  const [address, setAddress] = useState('');

  const handleAddAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const newAppt: Appointment = {
      id: Date.now().toString(),
      clientName,
      clientPhone,
      clientAddress: address,
      serviceDate: new Date(serviceDate),
      startTime,
      durationHours: 2,
      services,
      totalPrice: parseFloat(totalPrice),
      status: ServiceStatus.PENDING,
      isPaid: false,
      reminderSent: false
    };
    
    // Sort by date immediately
    const updated = [...appointments, newAppt].sort((a, b) => 
       new Date(a.serviceDate).getTime() - new Date(b.serviceDate).getTime()
    );

    setAppointments(updated);
    setIsFormOpen(false);
    // Reset form
    setClientName('');
    setClientPhone('');
    setServiceDate('');
    setStartTime('');
    setServices('');
    setTotalPrice('');
    setAddress('');
  };

  const updateStatus = (id: string, newStatus: ServiceStatus) => {
    setAppointments(appointments.map(appt => 
      appt.id === id ? { ...appt, status: newStatus } : appt
    ));
  };

  const togglePaid = (id: string) => {
      setAppointments(appointments.map(appt => 
          appt.id === id ? { ...appt, isPaid: !appt.isPaid } : appt
      ));
  };

  const handleSixMonthReturn = (appt: Appointment) => {
      const returnDate = new Date(appt.serviceDate);
      returnDate.setMonth(returnDate.getMonth() + 6);
      
      const confirmCreate = window.confirm(`Criar um pré-agendamento de retorno para ${returnDate.toLocaleDateString('pt-BR')}?`);
      
      if (confirmCreate) {
        const newAppt: Appointment = {
            ...appt,
            id: Date.now().toString(),
            serviceDate: returnDate,
            status: ServiceStatus.PENDING,
            isPaid: false,
            reminderSent: false,
            services: `Manutenção: ${appt.services}`
        };
        const updated = [...appointments, newAppt].sort((a, b) => 
            new Date(a.serviceDate).getTime() - new Date(b.serviceDate).getTime()
        );
        setAppointments(updated);
      }
  };

  const openChecklist = (id: string) => {
      setActiveChecklistId(id);
      // Reset checklist steps for new session (simple implementation)
      setChecklistSteps({
        photoBefore: false,
        protectFloor: false,
        vacuum: false,
        applyProduct: false,
        extract: false,
        photoAfter: false,
        cleanArea: false
      });
  };

  const getStatusColor = (status: ServiceStatus) => {
    switch (status) {
      case ServiceStatus.CONFIRMED: return 'bg-blue-100 text-blue-700 border-blue-200';
      case ServiceStatus.COMPLETED: return 'bg-green-100 text-green-700 border-green-200';
      case ServiceStatus.CANCELLED: return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-yellow-100 text-yellow-700 border-yellow-200';
    }
  };

  // Quick Action Helpers
  const openWhatsApp = (phone: string, message: string) => {
      if (!phone) {
          alert("Telefone do cliente não cadastrado");
          return;
      }
      const cleanPhone = phone.replace(/\D/g, '');
      const url = `https://wa.me/55${cleanPhone}?text=${encodeURIComponent(message)}`;
      window.open(url, '_blank');
  };

  const openMap = (address: string) => {
      if (!address) return;
      const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
      window.open(url, '_blank');
  };

  const handleLiabilityTerm = (appt: Appointment) => {
      const message = `Olá ${appt.clientName}, para iniciarmos a higienização com segurança, preciso registrar que o estofado apresenta [Descreva aqui: manchas antigas / desgaste no tecido / rasgo] na área [local].\n\nO procedimento visa a limpeza e higienização, não sendo possível reverter danos físicos ao tecido já existentes. Podemos prosseguir?`;
      openWhatsApp(appt.clientPhone, message);
  };

  return (
    <div className="space-y-6 pb-20">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Agenda de Serviços</h2>
          <p className="text-gray-500">Gerencie seus compromissos futuros</p>
        </div>
        <button 
          onClick={() => setIsFormOpen(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-xl hover:bg-blue-700 transition-colors flex items-center gap-2 shadow-lg shadow-blue-200"
        >
          <Plus size={20} />
          <span className="hidden sm:inline">Novo Agendamento</span>
        </button>
      </div>

      {isFormOpen && (
        <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 animate-in fade-in zoom-in duration-300">
           <h3 className="font-bold text-lg mb-4 text-gray-800">Adicionar Serviço</h3>
           <form onSubmit={handleAddAppointment} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input required type="text" placeholder="Nome do Cliente" className="p-2 border rounded-lg" value={clientName} onChange={e => setClientName(e.target.value)} />
              <input required type="tel" placeholder="WhatsApp (com DDD)" className="p-2 border rounded-lg" value={clientPhone} onChange={e => setClientPhone(e.target.value)} />
              <input required type="text" placeholder="Endereço Completo" className="p-2 border rounded-lg md:col-span-2" value={address} onChange={e => setAddress(e.target.value)} />
              <input required type="date" className="p-2 border rounded-lg" value={serviceDate} onChange={e => setServiceDate(e.target.value)} />
              <input required type="time" className="p-2 border rounded-lg" value={startTime} onChange={e => setStartTime(e.target.value)} />
              <input required type="text" placeholder="Serviços (ex: Sofá 3L)" className="p-2 border rounded-lg md:col-span-2" value={services} onChange={e => setServices(e.target.value)} />
              <input required type="number" placeholder="Valor (R$)" className="p-2 border rounded-lg" value={totalPrice} onChange={e => setTotalPrice(e.target.value)} />
              
              <div className="md:col-span-2 flex justify-end gap-2 mt-2">
                 <button type="button" onClick={() => setIsFormOpen(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Cancelar</button>
                 <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Salvar</button>
              </div>
           </form>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {appointments.map((appt) => (
          <div key={appt.id} className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow relative overflow-hidden group flex flex-col">
            
            {/* Payment Toggle Overlay */}
            <button 
                onClick={() => togglePaid(appt.id)}
                className={`absolute top-4 right-20 px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1 transition-all z-10 ${
                    appt.isPaid 
                    ? 'bg-green-100 text-green-700 border-green-200' 
                    : 'bg-gray-100 text-gray-400 border-gray-200 hover:bg-gray-200'
                }`}
            >
                <DollarSign size={12} />
                {appt.isPaid ? 'PAGO' : 'A PAGAR'}
            </button>

            {/* Status Badge */}
            <div className={`absolute top-4 right-4 px-2 py-1 rounded-full text-xs font-bold border ${getStatusColor(appt.status)}`}>
              {appt.status}
            </div>

            <div className="mb-3 pr-24 mt-6 sm:mt-0">
              <h3 className="font-bold text-gray-800 text-lg flex items-center gap-2 truncate">
                <User size={18} className="text-blue-500 flex-shrink-0" />
                {appt.clientName}
              </h3>
              <button 
                onClick={() => openMap(appt.clientAddress)}
                className="text-gray-500 text-sm mt-1 flex items-start gap-2 hover:text-blue-600 transition-colors text-left group/addr"
              >
                 <MapPin size={14} className="flex-shrink-0 mt-0.5" />
                 <span className="group-hover/addr:underline decoration-blue-300 line-clamp-2">{appt.clientAddress}</span>
                 <ExternalLink size={10} className="opacity-0 group-hover/addr:opacity-100" />
              </button>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-xl mb-4 space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Clock size={16} className="text-gray-400"/>
                <span className="font-semibold">
                    {new Date(appt.serviceDate).toLocaleDateString('pt-BR')} às {appt.startTime}
                </span>
              </div>
              <div className="text-sm text-gray-600 pl-6 truncate">
                {appt.services}
              </div>
              <div className="text-sm font-bold text-blue-600 pl-6">
                Valor: R$ {appt.totalPrice.toFixed(2)}
              </div>
            </div>

            {/* Quick Actions Row */}
            <div className="grid grid-cols-4 gap-2 mb-4 border-b border-gray-100 pb-4">
                <button 
                   onClick={() => openWhatsApp(appt.clientPhone, `Olá ${appt.clientName}, confirmando nosso agendamento para ${new Date(appt.serviceDate).toLocaleDateString('pt-BR')} às ${appt.startTime}. Tudo certo?`)}
                   className="flex flex-col items-center justify-center gap-1 p-2 rounded-lg bg-gray-50 text-gray-600 hover:bg-green-50 hover:text-green-700 transition-colors text-[10px] font-medium"
                   title="Confirmar Presença"
                >
                    <CheckCircle size={16} />
                    Confirmar
                </button>
                <button 
                   onClick={() => openWhatsApp(appt.clientPhone, `Olá ${appt.clientName}, estou a caminho do local! Chego em breve.`)}
                   className="flex flex-col items-center justify-center gap-1 p-2 rounded-lg bg-gray-50 text-gray-600 hover:bg-blue-50 hover:text-blue-700 transition-colors text-[10px] font-medium"
                   title="Avisar que está a caminho"
                >
                    <Navigation size={16} />
                    A Caminho
                </button>
                <button 
                   onClick={() => handleLiabilityTerm(appt)}
                   className="flex flex-col items-center justify-center gap-1 p-2 rounded-lg bg-gray-50 text-gray-600 hover:bg-orange-50 hover:text-orange-700 transition-colors text-[10px] font-medium"
                   title="Termo de Avaria / Ciência"
                >
                    <ShieldAlert size={16} />
                    Termo/Avaria
                </button>
                <button 
                   onClick={() => openWhatsApp(appt.clientPhone, `Olá ${appt.clientName}, obrigado pela preferência! Segue meus dados para pagamento do valor de R$ ${appt.totalPrice.toFixed(2)}...`)}
                   className="flex flex-col items-center justify-center gap-1 p-2 rounded-lg bg-gray-50 text-gray-600 hover:bg-purple-50 hover:text-purple-700 transition-colors text-[10px] font-medium"
                   title="Enviar Cobrança/PIX"
                >
                    <MessageCircle size={16} />
                    Cobrança
                </button>
            </div>

            {/* Execution / Completed Actions */}
            {appt.status !== ServiceStatus.COMPLETED && appt.status !== ServiceStatus.CANCELLED ? (
                <button 
                    onClick={() => openChecklist(appt.id)}
                    className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold text-sm shadow-md shadow-blue-200 hover:bg-blue-700 transition-colors flex items-center justify-center gap-2 mb-2"
                >
                    <Play size={16} /> Iniciar Serviço (Checklist)
                </button>
            ) : null}

            {/* Post-Service Actions (Visible if completed) */}
            {appt.status === ServiceStatus.COMPLETED && (
                <div className="grid grid-cols-2 gap-2 mb-4">
                    <button 
                        onClick={() => openWhatsApp(appt.clientPhone, `Olá ${appt.clientName}! Gostaria de saber o que achou do serviço? Se puder nos avaliar, agradeço muito!`)}
                        className="flex items-center justify-center gap-2 p-2 rounded-lg border border-yellow-200 text-yellow-700 hover:bg-yellow-50 text-xs font-medium"
                    >
                        <Star size={14} /> Pedir Avaliação
                    </button>
                    <button 
                        onClick={() => handleSixMonthReturn(appt)}
                        className="flex items-center justify-center gap-2 p-2 rounded-lg border border-purple-200 text-purple-700 hover:bg-purple-50 text-xs font-medium"
                    >
                        <CalendarPlus size={14} /> Retorno 6 meses
                    </button>
                </div>
            )}
            
            {/* Status Toggles for Pending Jobs */}
            {appt.status !== ServiceStatus.COMPLETED && appt.status !== ServiceStatus.CANCELLED && (
                <div className="flex gap-2">
                    <button 
                        onClick={() => updateStatus(appt.id, ServiceStatus.COMPLETED)}
                        className="flex-1 border border-gray-200 text-gray-500 py-2 rounded-lg text-xs hover:bg-gray-50 transition-colors"
                    >
                        Marcar Concluído
                    </button>
                    <button 
                        onClick={() => updateStatus(appt.id, ServiceStatus.CANCELLED)}
                        className="px-3 border border-red-100 text-red-400 py-2 rounded-lg text-xs hover:bg-red-50 transition-colors"
                    >
                        Cancelar
                    </button>
                </div>
            )}
          </div>
        ))}
      </div>

      {/* Checklist Modal */}
      {activeChecklistId && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
             <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl animate-in fade-in zoom-in duration-200">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        <ListChecks className="text-blue-600"/> Checklist
                    </h3>
                    <button onClick={() => setActiveChecklistId(null)} className="p-1 rounded-full hover:bg-gray-100">
                        <XCircle className="text-gray-400" />
                    </button>
                </div>
                
                <div className="space-y-4 mb-8">
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.photoBefore} onChange={() => setChecklistSteps({...checklistSteps, photoBefore: !checklistSteps.photoBefore})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">1. Foto do Antes (Avaria?)</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.protectFloor} onChange={() => setChecklistSteps({...checklistSteps, protectFloor: !checklistSteps.protectFloor})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">2. Proteger Piso</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.vacuum} onChange={() => setChecklistSteps({...checklistSteps, vacuum: !checklistSteps.vacuum})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">3. Aspiração Profunda</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.applyProduct} onChange={() => setChecklistSteps({...checklistSteps, applyProduct: !checklistSteps.applyProduct})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">4. Aplicação / Escovação</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.extract} onChange={() => setChecklistSteps({...checklistSteps, extract: !checklistSteps.extract})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">5. Extração / Enxágue</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.cleanArea} onChange={() => setChecklistSteps({...checklistSteps, cleanArea: !checklistSteps.cleanArea})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">6. Limpeza do Local (Chão)</span>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer transition-all has-[:checked]:border-green-500 has-[:checked]:bg-green-50">
                        <input type="checkbox" checked={checklistSteps.photoAfter} onChange={() => setChecklistSteps({...checklistSteps, photoAfter: !checklistSteps.photoAfter})} className="w-5 h-5 text-green-600 rounded focus:ring-green-500" />
                        <span className="font-medium text-gray-700">7. Foto do Depois</span>
                    </label>
                </div>

                <button 
                    onClick={() => {
                        updateStatus(activeChecklistId, ServiceStatus.COMPLETED);
                        setActiveChecklistId(null);
                    }}
                    className="w-full bg-green-600 text-white py-4 rounded-xl font-bold shadow-lg shadow-green-200 hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                >
                    <CheckCircle size={20} /> Finalizar Serviço
                </button>
             </div>
          </div>
      )}
    </div>
  );
};